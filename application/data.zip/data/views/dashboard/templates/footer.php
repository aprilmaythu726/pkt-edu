<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

          <footer class="footer">
            <p class="text-muted m-0">
            <small >Copyrigth © 2021  &nbsp;&nbsp;&nbsp;<span class="material-icons align-middle md-16 mb-1">select_all</span> {elapsed_time}s</small>
            <small class="float-right">Develop by <a href="http://maymyanmarlin.com/mm/" target="_blank" class="text-danger">MML @neroaquarious</a> </small>
            </p>
            
          </footer>
      </div>
    </div>
  </section>

  <div class="loading"><div class="spinner"><div class="spinner__rect spinner__rect--1"></div> <div class="spinner__rect spinner__rect--2"></div> <div class="spinner__rect spinner__rect--3"></div> <div class="spinner__rect spinner__rect--4"></div> <div class="spinner__rect spinner__rect--5"></div></div></div>
    
    <script src="<?php echo base_url('asset/admin/js/lib/moment.min.js'); ?>"></script>
    <script src="<?php echo base_url('asset/admin/js/lib/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('asset/admin/js/lib/popper.min.js'); ?>"></script>
    <script src="<?php echo base_url('asset/admin/js/jquery.dataTables.min.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('asset/admin/js/dataTables.bootstrap4.min.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('asset/admin/js/bootstrap/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('asset/admin/js/chosen-js/chosen.jquery.js'); ?>"></script>
    <script src="<?php echo base_url('asset/admin/js/ekko-lightbox/ekko-lightbox.js'); ?>"></script>
    <script src="<?php echo base_url('asset/admin/js/custom.js'); ?>"></script>

    <?php include("script.php"); ?>
  </body>
</html>