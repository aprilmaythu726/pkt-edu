<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Slider -->
<div class="slider-area">
  <div class="bend niceties preview-2">
      <div id="ensign-nivoslider" class="slides"> 
          <!--   <video autoplay muted loop>
              <source src="<?php echo base_url('asset/images/about/pkt.mp4'); ?>" type="video/mp4">
              <source src="<?php echo base_url('asset/images/about/pkt.mp4'); ?>" type="video/ogg">
              Your browser does not support the video tag.
            </video> -->
             <img src="<?php echo base_url('asset/images/about/2year_batch3_1.jpg'); ?>" alt="">
        <img src="<?php echo base_url('asset/images/about/2year_batch3_2.jpg'); ?>" alt="">
      </div>
      <!-- direction 1 -->
      
      <!-- direction 2 -->
      <div id="slider-direction-2" class="slider-direction">
          <div class="slider-progress"></div>
          <div class="slider-content t-lfl s-tb slider-2">
              <div class="title-container s-tb-c">
                  <h1>Best Learning System</h1>
                  <p>We look Forward To Getting to know you and to helipng you take your business to new heights!Intense is an International Financial Planning company with offices.</p>
                  <div class="slider-button">
                      <ul>
                          <li><a href="#">Contact Us</a></li>
                      </ul>
                  </div>
              </div>
          </div>  
      </div>
      <!-- direction 3 -->
      <div id="slider-direction-3" class="slider-direction">
          <div class="slider-progress"></div>
          <div class="slider-content t-lfr s-tb slider-3">
              <div class="title-container s-tb-c">
                  <h1>Undergraduate Degree Opeing</h1>
                  <p>We look Forward To Getting to know you and to helipng you take your business to new heights!Intense is an International Financial Planning company with offices.</p>
                  <div class="slider-button">
                      <ul>
                          <li><a href="#">Read More</a></li>
                      </ul>
                  </div>
              </div>
          </div>  
      </div>
  </div>
</div>
<!-- Slider end-->